#!/usr/bin/env -S npx tsx
/**
 * hooks/pre-compact.ts
 *
 * Event:   PreCompact
 * Purpose: No-op log-emitter per architect's audit. PreCompact fires
 *          before Claude Code compacts conversation context (clearing
 *          the working buffer). For Guild this is a useful trace
 *          point: any in-flight phase/lane state should be flushed to
 *          .guild/runs/<run-id>/logs before the host buffers reset.
 *
 *          The handler emits a `hook_event` JSONL line via T3c's
 *          appendEvent() so the audit log captures the compact
 *          boundary. Falls through cleanly when GUILD_RUN_ID is unset
 *          (host runs outside a tracked /guild lifecycle session).
 *
 * Stdin:   JSON — Claude Code PreCompact hook payload.
 * Stdout:  Silent (Claude Code may consume it).
 * Stderr:  Diagnostic warnings only.
 * Exit:    Always 0 — telemetry must not block.
 *
 * Run-id resolution: process.env.GUILD_RUN_ID. Unset → fall through.
 *
 * runDir resolution:
 *   1. process.env.GUILD_RUN_DIR
 *   2. resolveGuildRoot(GUILD_CWD | payload.cwd | process.cwd()) + .guild/runs/<run-id>
 *      resolveGuildRoot walks UP from the starting cwd to the nearest .git / .guild
 *      ancestor so .guild/ always lands at the repo root, never in a subdirectory.
 */

import * as fs from "node:fs";
import * as path from "node:path";

import { resolveGuildRoot } from "./lib/guild-root.js";
import { appendEvent, type HookEvent } from "./lib/v1.4/log-jsonl.js";
// guild.trace_event.v2 additive fields (D-OBS-1/6). Bound BY POINTER — see
// lib/trace-v2.ts header. Hook events are not LLM calls → no tokens.
import { resolveTraceV2Fields } from "./lib/trace-v2.js";

interface PreCompactPayload {
  session_id?: string;
  cwd?: string;
  hook_event_name?: string;
  /** Optional per-host payload — the architect contract treats it as opaque. */
  payload?: unknown;
}

async function readStdin(): Promise<string> {
  return new Promise((resolve) => {
    const chunks: Buffer[] = [];
    process.stdin.on("data", (c: Buffer) => chunks.push(c));
    process.stdin.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    process.stdin.on("error", () => resolve(""));
  });
}

/**
 * Build a short string excerpt from an arbitrary payload value. The
 * downstream `redactEventFields` applies token-shape patterns + field
 * caps; here we only stringify so the redaction pipeline has something
 * to work with.
 */
function payloadExcerpt(payload: unknown): string {
  if (payload === undefined || payload === null) return "";
  if (typeof payload === "string") return payload;
  try {
    return JSON.stringify(payload);
  } catch {
    return "";
  }
}

function readCurrentRunId(guildRoot: string): string | undefined {
  const sentinelPath = path.join(guildRoot, ".guild", "runs", "current-run-id");
  try {
    const value = fs.readFileSync(sentinelPath, "utf8").trim();
    return value.length > 0 ? value : undefined;
  } catch {
    return undefined;
  }
}

function resolveRunId(guildRoot: string): string | undefined {
  const envRunId = process.env["GUILD_RUN_ID"];
  if (typeof envRunId === "string" && envRunId.length > 0) return envRunId;
  return readCurrentRunId(guildRoot);
}

export async function main(): Promise<void> {
  const raw = await readStdin();
  let payload: PreCompactPayload = {};
  try {
    if (raw.trim().length > 0) {
      payload = JSON.parse(raw.trim()) as PreCompactPayload;
    }
  } catch {
    process.stderr.write("warn: [pre-compact] invalid JSON on stdin; emitting bare event.\n");
  }

  const cwd = process.env["GUILD_CWD"] ?? payload.cwd ?? process.cwd();
  // Walk up from cwd to find the repo root — ensures .guild/ always lands at
  // the nearest .git / .guild ancestor, never in a subdirectory.
  const guildRoot = resolveGuildRoot(cwd);
  const runId = resolveRunId(guildRoot);
  if (typeof runId !== "string" || runId.length === 0) {
    process.stderr.write(
      "warn: [pre-compact] GUILD_RUN_ID unset and current-run-id missing — falling through (no log emit).\n",
    );
    return;
  }

  const runDir =
    process.env["GUILD_RUN_DIR"] ??
    path.join(guildRoot, ".guild", "runs", runId);

  const ts = new Date().toISOString();
  const event: HookEvent = {
    ts,
    event: "hook_event",
    run_id: runId,
    hook_name: "PreCompact",
    payload_excerpt_redacted: payloadExcerpt(payload.payload),
    latency_ms: 0,
    status: "ok",
  };
  // D-OBS-1/6: span_id + env-threaded tier/model/parent (no tokens for hooks).
  const traceV2 = resolveTraceV2Fields({
    runId,
    eventType: "hook_event",
    ts,
    actorId: "main",
  });

  try {
    appendEvent(runDir, event, { traceV2 });
  } catch (err) {
    process.stderr.write(
      `warn: [pre-compact] log emit failed: ${
        err instanceof Error ? err.message : String(err)
      }\n`,
    );
  }
}

if (
  process.argv[1] !== undefined &&
  (process.argv[1].endsWith("pre-compact.ts") ||
    process.argv[1].endsWith("pre-compact.js"))
) {
  main().catch((err: unknown) => {
    process.stderr.write(
      `fatal: [pre-compact] ${
        err instanceof Error ? err.message : String(err)
      }\n`,
    );
    process.exit(0);
  });
}
