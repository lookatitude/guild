---
type: concept
owner: architect
confidence: high
source_refs: ["guild-plan.md §13.1"]
created_at: 2026-05-17
updated_at: 2026-07-12
expires_at: null
supersedes: "guild-plan.md §13.1"
sensitivity: public
applies_to: [plugin]
related: [command-surface, v2-index, phase-entrypoints]
---

# Guild v1 → v2 Migration

> **Status: design documentation.** This document *describes* the v1 → v2
> migration and the exact user-visible behavior of every removed/renamed
> command. It does not execute the migration and does not edit anything under
> `plugin/`. The canonical, authoritative copy lives **here at
> `plugin/.<HIGH_ENTROPY_REDACTED>.md`** (v2 — moved from the retired root
> docs KB on 2026-06-27); cross-reference links resolve to the v2 wiki
> (`../decisions/…`, sibling `entities/…`). **This is the single source of truth
> — edit only this file.** The repo-root **`./MIGRATION.md`** is a *generated*
> pointer stub (carries a "do not edit by hand" banner; its 30-second digest is
> extracted from this file's §1). A drift `--check` mode re-derives it and fails
> on any divergence, so it cannot silently fall out of sync.

This is the definitive v2 migration guide: it documents every removed/renamed
command, the config and flag changes, and the new-in-v2 surfaces a v1 user
will encounter. v2 is a full clean slate — Guild **keeps** the `:` plugin
namespace (a Claude Code requirement) but **drops the redundant `guild-`
command prefix** (v1 `/guild:guild-wiki` → v2 `/guild:wiki`), the Operations
verb is `ops`, and `--rigor=deep` auto-implies `--review=cross`.

---

## 1. TL;DR (the 60-second version)

<!-- STUB-DIGEST:START -->
- `/guild:guild-x` → `/guild:x` — the `:` plugin namespace **stays** (Claude
  Code requires it); v2 drops the **redundant `guild-` command prefix** and
  changes the verb set. The bare entry is **`/guild:guild`** (there is no
  bare `/guild`).
- Flag soup → **`--rigor=quick|standard|deep`** + 5 global flags + a
  universal `--dry-run` + a handful of scoped per-command locals.
- New **phase subcommands**: `init ideate plan build qa ops`
  (the Operations verb is **`ops`**).
- `/guild:guild-team` is **removed** — team-compose is folded into `/guild:plan`.
- `/guild:guild-diagnose` → **`/guild:fix`**.
- **Initiatives are NEW and OPT-IN** — one-off runs stay first-class.
- **No shims that execute.** Every removed name prints a redirect and exits
  non-zero (documentation, not a behavioral shim). **Redirect stubs were
  deleted in this release (v2.0).** A bare unknown subcommand prints usage
  help only.
<!-- STUB-DIGEST:END -->

Full design spec: [architecture/command-surface.md](command-surface.md).

---

## 2. Command-by-command mapping

The eight shipped v1 commands and their v2 fate, with the **exact
user-visible redirect message** each removed/renamed name prints.

### 2.1 The mapping table

| v1 command | v2 replacement | Behavior delta | Fate |
|---|---|---|---|
| `/guild:guild [brief] [--loops --loop-cap --auto-approve --codex-review --codex-cap]` | `/guild:guild [brief]` + phase subcommands `init/ideate/plan/build/qa/ops`; flags → `--rigor` + 5 globals | Phases now addressable; flag soup consolidated under `--rigor` (the tuning flags stay supported for power users); surfaced phase auto-detect added | renamed / restructured (not removed) |
| `/guild:guild-team [propose\|show\|edit] [--allow-larger]` | **removed.** `propose`→ inside `/guild:plan`; `show`→ `/guild:status` (team section); `edit`→ the `[edit]` response at the plan/team approval gate; `--allow-larger`→ `--team-size=N` on `/guild:plan` | Team is no longer a standalone surface; it is a planning sub-step | **REMOVED** |
| `/guild:guild-wiki [ingest\|query\|lint]` | `/guild:wiki <ingest\|query\|lint>` | prefix drop only; behavior identical | renamed |
| `/guild:guild-evolve [skill] [--auto]` | `/guild:evolve [skill] [--auto]` | prefix drop only | renamed |
| `/guild:guild-rollback <skill> [n]` | `/guild:rollback <skill> [n]` | prefix drop only | renamed |
| `/guild:guild-stats` | `/guild:stats` | prefix drop only | renamed |
| `/guild:guild-audit` | `/guild:audit` | prefix drop only | renamed |
| `/guild:guild-diagnose [run-id\|text] [--codex-review]` | `/guild:fix [run-id\|"symptom"] [--review=cross]` | prefix drop + verb rename diagnose→fix; `--codex-review`→`--review=cross` | renamed + flag-migrated |

Designed-but-unshipped commands placed:

| Designed command | v2 placement |
|---|---|
| `/guild:guild-init` | → `/guild:init` (phase subcommand) |
| `/guild:guild-initiative new\|status\|resume\|update\|close` | → `/guild:initiative <…>` (opt-in) |
| quality entrypoint | → `/guild:qa` |
| operations entrypoint | → `/guild:ops` (the Operations verb is `ops`) |

### 2.2 Exact user-visible redirect messages (per row)

Every removed/renamed name prints one of the following, then **exits
non-zero and runs nothing**. This is the documented behavior, not a
functional shim.

**Generic renamed (prefix drop)** — applies to `/guild:guild-wiki`,
`/guild:guild-evolve`, `/guild:guild-rollback`, `/guild:guild-stats`,
`/guild:guild-audit`. Example for `/guild:guild-wiki`:

```
/guild:guild-wiki was renamed in Guild v2.

  v2 equivalent:  /guild:wiki <ingest|query|lint>

Guild v2 keeps the `:` namespace; it drops the redundant `guild` prefix — every command is /guild:<verb>.
Full mapping: MIGRATION.md  (repo root or plugin/MIGRATION.md).
```

Substitute the verb for each of the other generically-renamed commands:

| Old | New | First line of redirect |
|---|---|---|
| `/guild:guild-evolve` | `/guild:evolve [skill] [--auto]` | `/guild:guild-evolve was renamed in Guild v2.` |
| `/guild:guild-rollback` | `/guild:rollback <skill> [n]` | `/guild:guild-rollback was renamed in Guild v2.` |
| `/guild:guild-stats` | `/guild:stats` | `/guild:guild-stats was renamed in Guild v2.` |
| `/guild:guild-audit` | `/guild:audit` | `/guild:guild-audit was renamed in Guild v2.` |

(Each prints the same body: `v2 equivalent: /guild:<verb> …` + the
prefix-drop explanation + the `Full mapping: MIGRATION.md` line.)

**Removed-outright `/guild:guild-team`:**

```
/guild:guild-team was removed in Guild v2 (no direct replacement).

Team composition is now a step inside planning:
  • propose  → run /guild:plan        (team is composed, then approved at the plan gate)
  • show     → /guild:status          (shows the active team)
  • edit     → answer [edit] at the plan/team approval gate
  • --allow-larger → /guild:plan --team-size=N   (prints the cap-6 warning)

Full mapping: MIGRATION.md §2.
```

**Verb-renamed `/guild:guild-diagnose`:**

```
/guild:guild-diagnose was renamed in Guild v2.

  v2 equivalent:  /guild:fix [run-id | "symptom"] [--review=cross]

(`--codex-review` is now `--review=cross`.)
Full mapping: MIGRATION.md §2.
```

**The mega-verb `/guild:guild [brief]`** is <HIGH_ENTROPY_REDACTED>, not removed — it
still works. The only behavioral change a user sees on first run is the
**surfaced phase-detection prompt** and the **tuning flags** (retained — CLI-accepted; config keys are the persistent equivalent) (see §4).

---

## 3. Config migration (`.guild/settings.json`)

> **v2 config surface: `.guild/settings.json` (JSON) replaces `.guild/config.yml` (YAML).**
> It is the single config file and holds every option (Tier-1 keys + the
> closed-key `defaults:` block). Scaffold it fully-documented with
> `/guild:config init`; inspect the resolved config with `/guild:config show`;
> check it with `/guild:config validate`. **The `.guild/config.yml` runtime
> reader was removed in v2.0** — `config.yml` is no longer read at runtime, and
> there is no back-compat shim. To convert a v1 `.guild/config.yml`, run
> `/guild:migrate` (the on-open converter — the only migration path). The key
> mapping below is what the converter applies; the precedence ladder is
> unchanged — only the file + format changed (YAML → JSON).

### 3.1 Key mapping

| v1 key | v2 key | Note |
|---|---|---|
| `loops:` | `loops:` (still present, but `null` = derive from `rigor`) | Prefer `rigor:`; `loops:` is now a power-user override only |
| `loop_cap:` | `loop_cap:` | CLI `--loop-cap=N` also accepted; config key is the persistent form |
| `codex_cap:` | `codex_cap:` | CLI `--codex-cap=N` also accepted; config key persists it |
| `codex_review: true\|false` | `review: local \| cross \| off` | `true`→`cross`, `false`→`local` |
| `auto_approve: none\|spec-and-plan\|implementation\|all` | `auto_approve: []` csv | `none`→`[]`, `spec-and-plan`→`[spec,plan]`, `implementation`→`[build]`, `all`→`[all]` |
| *(new)* | `rigor: standard` | New profile knob; the primary control |
| *(new)* | `host: auto` | New host-adapter selection |
| *(new)* | `initiative_default: null` | New; still opt-in |
| `defaults.agent_team: true\|false` | `agent_mode: team\|agent\|subagent\|auto` (Tier-1) | **Replaced by the dispatch ladder (D5).** `true`→`team`, `false`→`subagent`, absent→`auto`. `defaults.agent_team` is **hard-removed in v2.0**: `--validate` REJECTS `agent_team` as an unknown key; resolve mode strips it. The `.guild/config.yml` runtime fallback reader is also removed — use the on-open converter (`/guild:migrate`) as the migration path. |
| *(new)* | `defaults.auto_learn: false` | When `true`, `/guild:init` runs the full `learn-*` pipeline at bootstrap (D3). Precedence: `--learn` flag > `settings.json` > built-in(`false`). |

### 3.2 Back-compat shim (removed in v2.0)

The `.guild/config.yml` runtime fallback reader (`read-guild-config.ts` back-compat shim)
**has been removed in v2.0**. `.guild/config.yml` is no longer read at runtime.

**Migration path:** run `/guild:migrate` (dry-run by default, safe) to detect a v1 `.guild/`
layout and convert it to v2. The converter snapshots the existing `.guild/` before
writing anything. See the migrate command reference in
[architecture/command-surface.md §3.5](command-surface.md).

### 3.3 Worked example

v1 `.guild/config.yml`:

```yaml
loops: all
loop_cap: 16
codex_review: true
codex_cap: 5
auto_approve: spec-and-plan
```

v2 equivalent (`.guild/settings.json` — JSON, not YAML):

```json
{
  "rigor": "deep",
  "auto_approve": ["spec", "plan"],
  "host": "auto",
  "initiative_default": null
}
```

`rigor: "deep"` already implies `review: "cross"` and expands to loops=all +
cap=16 in one knob, so there is no separate `review` key to set. Power users
who need to pin exact knobs independent of the profile may add `"loops": null`
(null = derive from rigor — recommended), `"loop_cap": 16`, and
`"codex_cap": 5`.

### 3.4 New optional `defaults:` block (nothing to migrate)

v2 adds an **optional** top-level `defaults:` block to `.guild/settings.json`
— a closed-key set of project-wide behavior defaults (adversarial,
team size/always-include, review workflow, skill policy, soft-gate
auto-approve, wiki share-mode, reporting verbosity, **`auto_learn`**). The exact
key set and the extended precedence ladder are specified in
[architecture/command-surface.md](command-surface.md) §4.4 (the
canonical schema — not re-spelled here).

> **v2.0 amendment (D5 dispatch ladder — shipped in this release).** The
> `defaults.agent_team` boolean is **superseded** by a new Tier-1 key
> `agent_mode: team|agent|subagent|auto` (default `auto`). On `auto` the run
> resolves the backend: inside tmux → team in-session; tmux installed → team in
> a detached session; host supports independent agents → agent; else →
> subagent (the documented fallback). **`defaults.agent_team` is hard-removed
> in v2.0**: it is rejected as an unknown key by `--validate`, stripped by
> resolve mode, and the `.guild/config.yml` runtime reader is gone. Migrate via
> `/guild:migrate`. The new `defaults.auto_learn` bool (default `false`) gates
> whether `/guild:init` runs the full `learn-*` pipeline at bootstrap. Both are
> closed-key additions; the reject rules are unchanged. See
> [decisions/v2x-command-surface-dispatch-and-internalization.md](../decisions/v2x-command-surface-dispatch-and-internalization.md).

What a v1 user needs to know for migration:

- **Absent `defaults:` ⇒ byte-identical to today.** It is purely additive;
  zero-config behavior is unchanged. There is **nothing to migrate** — you
  only add it if you want project-wide defaults.
- **It lives in `.guild/settings.json`** (the single v2 config file, which
  replaces `.guild/config.yml`). Generate it with `/guild:config init`; the
  `defaults:` block is one section of it. An existing v1 `config.yml` is
  **converted to `settings.json` by `/guild:migrate`** — there is no runtime
  `config.yml` reader in v2.
- **Precedence:** a CLI flag still wins, then the `--rigor` profile, then
  your `defaults:` block, then the built-in default. Each folded key is
  printed in the pre-first-gate profile line, so a default is never silent.
- **Identity vs behavior split.** `project.yaml` is now identity-only
  (name, slug, label taxonomy, initiative identity); all *behavior* lives in
  `settings.json`. In particular `wiki.share_mode` moved from `project.yaml`
  into `settings.json`'s `defaults.wiki.share_mode`. If you previously set
  `share_mode` in `project.yaml`, move it under
  `defaults: { wiki: { share_mode: … } }` in `settings.json`.
- **Unknown keys are rejected** (config is human-authored, not
  lenient-read); `defaults.wiki.autopromote: true` is rejected always and
  `defaults.adversarial: off` is rejected for Guild self-build.

---

## 3a. Wiki knowledge migration — importance backfill + review gate

v1 wiki pages carry no v2 `importance:` frontmatter, which would make migrated
knowledge second-class in v2 recall ranking and coverage reporting. When
`/guild:migrate --mode=migrate` runs (snapshot-first, as always), the converter
also **drafts** a grade onto every ungraded `.guild/wiki/` page by deterministic
heuristics:

| Page | Drafted grade |
|---|---|
| `standards/**`, architecture-map, `decisions/**` (or `type: decision`) | `high` |
| provenance / exploratory pages (`research/`/`ideation/`/`sources/`, or frontmatter marking provenance\|exploratory\|source) | **skipped** — confidence-graded only, never importance |
| structural pages (`index.md`, `README.md`, `log.md`, `lint-*`) | skipped |
| everything else | `medium` |

A page that already has `importance:` is **never touched**. Drafted pages get a
frontmatter block if absent and are marked `importance_draft: true` +
`graded_by: guild-migrate` — drafts are *proposals, not facts*.

**The flow (the gate is the only human step):**

1. `migrate` → the migration report **ends** with the drafted-grades review table.
2. Review each grade; edit the `importance:` value in place where the heuristic
   is wrong (the closed enum is `critical | high | medium | low`; marquee
   features are `critical`, no exception).
3. Accept: `npx tsx plugin/scripts/dot-guild/migrate-guild.ts --accept-grades --root=<repo>`
   — strips the `importance_draft`/`graded_by` markers, keeps the grade.
4. Until you accept, wiki lint nags: `/guild:wiki lint` (check #9) and the
   docs-hygiene scan (rule 7) flag every page still carrying
   `importance_draft: true` as a pending-review item.

`--mode=dry-run` lists every planned grade without writing anything. The
snapshot taken before conversion holds the original ungraded pages, so the
documented restore command rolls the wiki back along with everything else.
Grading taxonomy: `.<HIGH_ENTROPY_REDACTED>-base-hygiene-and-grading.md`.

---

## 4. Flag migration cheat-sheet

| v1 flag | v2 |
|---|---|
| `--loops=<…>` | **retained** — still parsed; `--rigor` or `loops:` is the recommended persistent form |
| `--loop-cap=N` | **retained** — still parsed; `loop_cap:` persists it |
| `--codex-cap=N` | **retained** — still parsed; `codex_cap:` persists it |
| `--codex-review` | **removed in v2.0** — use `--review=cross` |
| `--auto-approve=spec-and-plan` | `--auto-approve=spec,plan` |
| `--auto-<HIGH_ENTROPY_REDACTED>` | `--auto-approve=build` |
| `--auto-approve=all` | `--auto-approve=all` (or bare `--auto-approve`) |
| `--restart` (first word of `$ARGUMENTS`) | `/guild:resume --restart` |
| `--allow-larger` (on `/guild:guild-team`) | `/guild:plan --team-size=N` |
| `--deep-scan` (on `/guild:init`) | `--learn` (one trigger name going forward; `init --learn` runs the same `learn-*` pipeline as `/guild:learn`, or set `defaults.auto_learn: true`) |

"Give me the old always-loop behavior" → `--rigor=deep` (or set
`rigor: deep` in `.guild/settings.json`). Note `--rigor=deep` also auto-implies
`--review=cross`; the expanded profile is printed before the first gate so
this is never a hidden mode.

---

## 5. Removed-command behavior (v2.0)

All v1→v2 redirect stubs were **deleted in v2.0** (this release). There is no
v2.1 deprecation window. A bare unknown subcommand prints usage help only.

| What | v2.0 behavior |
|---|---|
| Removed/renamed v1 command names | **Deleted.** A bare unknown subcommand token prints usage help and exits non-zero; it runs nothing. |
| `defaults.agent_team` config key | **Hard-removed.** Rejected by `--validate` as an unknown key; stripped by resolve mode. Migrate via `/guild:migrate`. |
| `--codex-review` flag | **Removed.** Use `--review=cross`. |
| `.guild/config.yml` runtime reader | **Removed.** Use `/guild:migrate` to convert a v1 layout to v2. |

---

## 5a. Additive v2.x additions (no breaking change)

### `models:` config block + `--model-tier` flag (cost-aware tiering)

Added in the `cost-aware-tiering-and-lean-context` initiative. Both are
**purely additive**; zero-config repos are unchanged (the built-in tier-map
biases cheap; absent `models:` block ⇒ current v2 behavior except cheaper
`learn-*`).

| Surface | What changed | Migration action |
|---|---|---|
| `settings.json` | New optional top-level closed-key `models:` block (master toggle, tier→model map, auto-score weights/thresholds, advisor rounds, escalation markers, recall settings, structured-output flag, cache TTL hints, importance gate). Unknown keys still rejected at Session Intake. | None required. Add the block to tune tiering; absent block ⇒ zero-config stable. Scaffold with `/guild:config init`. |
| CLI | New flag `--model-tier=cheap\|mid\|powerful` pins the tier for a run (top of precedence ladder). | None required. Use the flag when you want to override the auto-scored tier for a single run. |

**Precedence ladder (normative):** `--model-tier` CLI flag > per-lane plan
override (`model_tier:`) > `settings.json models:` block > built-in default.

Full specification: `plugin/.guild/wiki/decisions/cost-aware-tiering-and-lean-context.md §10`
(config keys) and §1–§6 (tier ladder, auto-score, advisor escalation, lean
lead, `guild.handoff.v2` schema, §task§agent lifecycle).

### Specialist roster → machinery agents + template library (v2.2)

Shipped on `next` after v2.1.0 (`machinery-agents-vs-specialist-template-library.md`).
The plugin now registers only the machinery agents (`advisor`, `developer`); the 15
domain specialists (architect … sales, incl. doc-writer) ship as type templates under
`<HIGH_ENTROPY_REDACTED>*.md` and are minted into the consuming repo's
`.guild/agents/<role>.md` at team-compose time, dispatching via the definition-path
mechanism. **Mostly additive, with one breaking edge:**

| Surface | What changed | Migration action |
|---|---|---|
| Host agent roster | `guild:architect`, `guild:backend`, … are no longer host-registered subagent types. | None for new work — team-compose mints instances on demand. Direct `subagent_type: <domain-role>` calls must go through the definition-path dispatch instead. |
| Existing `.guild/team/*.yaml` | Entries carrying `definition_source: shipped` for a DOMAIN role can no longer dispatch (the host has no agent under that name). | Run the one-shot fixer: `npx tsx ${GUILD_PLUGIN_ROOT:-${CLAUDE_PLUGIN_ROOT}}/scripts/roster-resolve.ts migrate-team-roster --cwd .` — it mints the missing instances (idempotent) and re-points each entry at `.guild/agents/<role>.md` / `definition_source: project`. Machinery agents are untouched. Or simply re-compose the phase team. |
| Minted instances | New optional projection: `roster-resolve.ts mint <role> --host-native` also copies the instance into `.claude/agents/<role>.md` (marker-stamped, never clobbers hand-authored files) so a Claude host can auto-route natively. | Opt-in only; nothing changes without the flag. |

## 6. New in v2 (not a migration, but you'll want these)

- **Phase entrypoints + surfaced smart detection** — start at any phase;
  bare `/guild:guild` proposes a phase and asks before proceeding (never silent).
  See [lifecycle/phase-entrypoints.md](phase-entrypoints.md).
- **Flat-token command surface + de-listed skills (D1/D2).** Beyond the
  prefix-drop (§1), v2.x normalizes the surface to Claude Code's real mechanics:
  commands are **flat** `/guild:<verb>` (colon-namespaced — the `:` stays) and
  sub-verbs (`wiki <ingest|query|lint>`,
  `config <init|show|validate>`, `learn <map|graph|onboard|diff|explain>`,
  `initiative <…>`) are **positional arguments**, never separate command files
  or nested namespaces — **filenames are the source of truth**, and any
  leftover `name: guild <verb>` frontmatter with a space is dead metadata.
  Guild **skills** (`brainstorm`, `plan`, `review`, …) are **model-invoked,
  never `/`-typed**; the command `/guild:<token>` and the skill `guild:<token>`
  are distinct surfaces that share a stem, so the `plan` / `init` / `audit`
  name overlaps are intentional, not collisions to fix. No user action — this
  is a surface clarification, not a behavior change.
- **Full skill internalization — zero dependency (D4).** Guild's borrowed
  methodology and understand-everything skills are now **clean-room
  re-authored** and Guild-native in name and behavior, with no runtime or
  conceptual dependency on the `superpowers` or `understand-anything` plugins.
  The per-skill `LICENSE-attribution.md` files and "forked from" blockquotes
  are removed; the redundant superpowers review forks
  (`request-review` / `receive-review` / `verify-claim`) are **folded into**
  Guild-native `review` / `verify-done`; and the methodology skills (`tdd`,
  `systematic-debug`, `worktrees`, `finish-branch`) are promoted out of the
  `fallback` "fork" tier into first-class skills. **No user-facing behavior
  change** — same capabilities, now owned outright.
- **Initiatives (opt-in durable work)** — `/guild:initiative …`. One-off
  runs remain first-class; an initiative attaches only on explicit request,
  `--initiative=`, or a durable-goal signal that *asks* first.
- **Cross-host review (`--review=cross`) + host adapter (`--host`)** — the
  Claude↔Codex reciprocal review broker.
- **`/guild:learn` (NEW) + cheap-by-default `/guild:init` (D3).** `/guild:init`
  stays cheap — wiki + a brownfield cheap-scan CodebaseMap + architecture-map
  stub. The full understand-everything pipeline (deep knowledge-graph,
  onboarding, diff, explain) is owned by the NEW
  `/guild:learn <map|graph|onboard|diff|explain>` command (one command file;
  the first positional selects the sub-verb). Init runs that full pipeline
  **only** when `defaults.auto_learn: true` or a `--learn` flag is passed —
  `--learn` folds in the old `--deep-scan` (one trigger name; one
  implementation, two triggers). See
  [decisions/v2x-command-surface-dispatch-and-internalization.md](../decisions/v2x-command-surface-dispatch-and-internalization.md).
- **`--rigor` profile** — one three-valued knob ("how careful should I be?")
  replaces five tuning flags.
- **Quality + Operations are full `[v2]` skills.** `/guild:qa` was a
  gap-report-only `verify-done`-extension; it is now the full `guild:quality`
  skill that **auto-selects and executes** E2E/smoke/a11y/perf/integration
  from `CodebaseMap` + plan signals (surfaced + overridable, never silent)
  behind a composer-derived producer/challenger advisory panel and an interactive release/blocker gate.
  `/guild:ops` was a reserved notice; it is now the full `guild:operations`
  skill that **executes** release/monitoring/incident/rollback/maintenance
  runbooks under a split autonomy posture with four non-negotiable safety
  rails. **This is not a breaking rename** — the command verbs `qa`/`ops`,
  their artifact paths (`quality/<run-id>.md`, `ops/<run-id>.md`), and the
  gate markers are unchanged; only the behavior behind them is promoted from
  deferred to shipped. Nothing in an existing v1 invocation changes.
- **`--auto-approve` BLOCK-override asymmetry (printed, never hidden).**
  `--auto-approve` collapses *soft* gates only. The frozen `--auto-approve`
  token set is `[spec,plan,build,all]` — there is **no `qa` or `ops`
  token**; Quality/Operations behavior is auto-passed **only under
  `--auto-approve=all`**, never via a `qa`/`ops` flag value (those do not
  exist). A Quality **BLOCK→release override is NOT a soft gate** (it
  overrides failing evidence) — it **stays human-gated even under
  `--auto-approve=all`**, exactly like the always-ask
  destructive/network/spend hard set. A RELEASE-READY recommendation *is*
  auto-passed under `--auto-approve=all`. The same asymmetry applies in
  Operations: a `release`, destructive, `incident`, or `rollback` action
  always prompts even under `--auto-approve=all` and even inside an
  `approved:true` autonomous runbook. If you set `--auto-approve=all`
  expecting it to mean *all*, this one printed line is the documented
  exception, not a hidden mode.
- **`.guild/` ownership boundary + `/guild:audit` boundary check.** v2
  formalizes the rule that every Guild-owned operational file (project
  config, the wiki, derived indexes, **project-authored or evolved agent and
  skill instances/overrides**, run records, learning/evolution records) is
  written under the consuming repo's `.guild/`. The plugin install directory
  is **static read-only base state** (canonical templates + base library),
  never runtime-written. The single normative ownership map and the
  enforcement model (one PreToolUse approval guard reusing the existing
  always-ask sandbox prompt — no new gate) are specified in
  [architecture/architecture-overview.md](../../../../.<HIGH_ENTROPY_REDACTED>-overview.md)
  and the boundary ADR it points to; the canonical config/boundary contract
  is in [architecture/command-surface.md](command-surface.md)
  §4.4/§3.5. **Migration impact for v1 users:** project-authored or evolved
  agents and skills now live at `.guild/agents/` and `.guild/skills/` (with a
  `derived_from_template:` stamp) rather than anywhere under the plugin
  install dir; `create-specialist`, the factory, and `evolve-skill` write
  there. If a prior workflow wrote instances into plugin state, that is a v2
  defect and those instances should be relocated under `.guild/`.
  **`/guild:audit` gains a static boundary-check section** that flags any Guild-owned
  file written outside `.guild/`. Nothing else changes for a standard user —
  the default zero-config layout already satisfies the boundary.
- **Optional `.guild/index.sqlite` read-through cache.** An optional,
  auto-managed SQLite cache may accelerate `/guild:status`, `/guild:resume`,
  `/guild:initiative status`, and `/guild:stats` rollups. It is **gitignored,
  fully deletable anytime with zero data loss, and never required** — the
  filesystem stays canonical (absence = identical filesystem-scan result). It
  is lazy-built only when scanning is measurably slow; set `index: off` in
  `.guild/settings.json` for zero hidden state. It is explicitly outside the
  plugin↔benchmark telemetry boundary (the benchmark imports only the
  canonical JSONL). Nothing to migrate; `rm .guild/index.sqlite` is always
  safe.

---

## 7. Self-build / CI callers

Internal scripts, the self-build pipeline, and any CI that invoked `/guild:*`
must be updated in the same break (these are ours to fix; not a user support
cost). Find/replace table:

| Find (v1) | Replace (v2) |
|---|---|
| `/guild:guild-audit` | `/guild:audit` |
| `/guild:guild-stats` | `/guild:stats` |
| `/guild:guild-wiki ` | `/guild:wiki ` |
| `/guild:guild-evolve` | `/guild:evolve` |
| `/guild:guild-rollback` | `/guild:rollback` |
| `/guild:guild-diagnose` | `/guild:fix` |
| `/guild:guild-team propose` | `/guild:plan` (team is a plan sub-step) |
| `/guild:guild-team show` | `/guild:status` |
| `--codex-review` | `--review=cross` |
| `--auto-approve=spec-and-plan` | `--auto-approve=spec,plan` |
| `--allow-larger` | `--team-size=N` (on `/guild:plan`) |

**SessionStart bootstrap:** the injected command list must be updated to the
3-daily tier (`/guild:guild [brief]`, `/guild:status`,
`/guild:wiki <ingest|query|lint>`) and should note the prefix-drop break
once. (Stated here as the required change; this design doc does not edit the
bootstrap or `plugin/CLAUDE.md`.)

**CI ergonomics note:** CI should name phases explicitly
(`/guild:build --auto-approve=…`) rather than rely on bare-`/guild:guild`
detection — detection is interactive by design. A bare `/guild:guild` reaching a
gate in a non-interactive context is expected to hard-fail with a clear
message rather than implicitly grant autonomy.

---

## 8. FAQ

**Why no shims?** v2 is a full clean slate — no shims that execute. The
redirect stubs were **removed in v2.0 (no sunset window)**; a bare unknown
subcommand now prints usage help only (§5). There is no v2.0.x→v2.1 support
tail to carry.

**Where did `/guild:guild-team` go?** Team composition is now a step *inside*
`/guild:plan` with its own approval gate. Inspect the active team via
`/guild:status`; edit it via the `[edit]` response at the plan/team gate;
raise the cap with `/guild:plan --team-size=N` (which prints the cap-6
warning).

**How do I get the old always-loop behavior?** Use `--rigor=deep` per
invocation, or set `rigor: deep` in `.guild/settings.json`. `deep` =
loops=all + cap=16 + `--review=cross` (auto-implied, profile printed
before the first gate).

**Did `/guild:guild-diagnose` just disappear?** No — it was *renamed* to
`/guild:fix`. The diagnose skill is retained internally; the command verb
changed because a user wants the thing fixed, not merely diagnosed.

**Is `/guild:guild` itself breaking?** The verb still works. You will see two
visible changes: a surfaced phase-detection prompt on bare `/guild:guild`, and the
addition of `--rigor` alongside the retained `--loops/--loop-cap/--codex-cap`
flags (config keys persist them).

---

## Cross-references

- [architecture/command-surface.md](command-surface.md) — the
  full clean-slate v2 command spec (the design source for this migration).
- [architecture/v2-index.md](../context/v2-index.md) — v2 architecture
  index; links this guide from the command-surface reading-order entry.
- [lifecycle/phase-entrypoints.md](phase-entrypoints.md) — binds
  each phase concept to its v2 command verb.
